-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Aug 24, 2015 at 11:52 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `to_do_m2m_test`
--
CREATE DATABASE IF NOT EXISTS `to_do_m2m_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `to_do_m2m_test`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=530 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories_tasks`
--

CREATE TABLE IF NOT EXISTS `categories_tasks` (
  `category_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=306 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories_tasks`
--

INSERT INTO `categories_tasks` (`category_id`, `task_id`, `id`) VALUES
(6, 78, 1),
(7, 84, 2),
(8, 85, 3),
(9, 85, 4),
(10, 91, 5),
(11, 92, 6),
(12, 92, 7),
(13, 98, 8),
(14, 99, 9),
(15, 99, 10),
(16, 105, 11),
(17, 106, 12),
(18, 106, 13),
(19, 112, 14),
(20, 113, 15),
(21, 113, 16),
(23, 120, 18),
(24, 121, 19),
(25, 121, 20),
(69, 141, 22),
(70, 142, 23),
(71, 142, 24),
(81, 153, 26),
(82, 154, 27),
(83, 154, 28),
(93, 165, 30),
(94, 166, 31),
(95, 166, 32),
(102, 168, 34),
(103, 169, 35),
(103, 170, 36),
(104, 171, 37),
(110, 172, 38),
(111, 173, 39),
(111, 174, 40),
(113, 181, 42),
(114, 182, 43),
(115, 182, 44),
(122, 184, 46),
(123, 185, 47),
(123, 186, 48),
(125, 193, 50),
(126, 194, 51),
(127, 194, 52),
(134, 196, 54),
(135, 197, 55),
(135, 198, 56),
(137, 205, 58),
(138, 206, 59),
(139, 206, 60),
(141, 213, 62),
(142, 214, 63),
(143, 214, 64),
(155, 216, 66),
(156, 217, 67),
(156, 218, 68),
(163, 220, 70),
(164, 221, 71),
(164, 222, 72),
(166, 229, 74),
(167, 230, 75),
(168, 230, 76),
(175, 232, 78),
(176, 233, 79),
(176, 234, 80),
(178, 241, 82),
(179, 242, 83),
(180, 242, 84),
(187, 244, 86),
(188, 245, 87),
(188, 246, 88),
(190, 253, 90),
(191, 254, 91),
(192, 254, 92),
(199, 256, 94),
(200, 257, 95),
(200, 258, 96),
(207, 260, 98),
(208, 261, 99),
(208, 262, 100),
(215, 264, 102),
(216, 265, 103),
(216, 266, 104),
(223, 268, 106),
(224, 269, 107),
(224, 270, 108),
(231, 272, 110),
(232, 273, 111),
(232, 274, 112),
(239, 276, 114),
(240, 277, 115),
(240, 278, 116),
(242, 285, 118),
(243, 286, 119),
(244, 286, 120),
(246, 293, 122),
(247, 294, 123),
(248, 294, 124),
(250, 301, 126),
(251, 302, 127),
(252, 302, 128),
(254, 309, 130),
(255, 310, 131),
(256, 310, 132),
(263, 312, 134),
(264, 313, 135),
(264, 314, 136),
(271, 316, 138),
(272, 317, 139),
(272, 318, 140),
(279, 320, 142),
(280, 321, 143),
(280, 322, 144),
(287, 324, 146),
(288, 325, 147),
(288, 326, 148),
(295, 328, 150),
(296, 329, 151),
(296, 330, 152),
(303, 332, 154),
(304, 333, 155),
(304, 334, 156),
(306, 341, 158),
(307, 342, 159),
(308, 342, 160),
(315, 344, 162),
(316, 345, 163),
(316, 346, 164),
(318, 353, 166),
(319, 354, 167),
(320, 354, 168),
(327, 356, 170),
(328, 357, 171),
(328, 358, 172),
(330, 365, 174),
(331, 366, 175),
(332, 366, 176),
(339, 368, 178),
(340, 369, 179),
(340, 370, 180),
(347, 372, 182),
(348, 373, 183),
(348, 374, 184),
(355, 376, 186),
(356, 377, 187),
(356, 378, 188),
(363, 380, 190),
(364, 381, 191),
(364, 382, 192),
(366, 389, 194),
(367, 390, 195),
(368, 390, 196),
(370, 397, 198),
(371, 398, 199),
(372, 398, 200),
(379, 400, 202),
(380, 401, 203),
(380, 402, 204),
(382, 409, 206),
(383, 410, 207),
(384, 410, 208),
(391, 412, 210),
(392, 413, 211),
(392, 414, 212),
(394, 421, 214),
(395, 422, 215),
(396, 422, 216),
(403, 424, 218),
(404, 425, 219),
(404, 426, 220),
(406, 433, 222),
(407, 434, 223),
(408, 434, 224),
(415, 436, 226),
(416, 437, 227),
(416, 438, 228),
(418, 445, 230),
(419, 446, 231),
(420, 446, 232),
(427, 448, 234),
(428, 449, 235),
(428, 450, 236),
(430, 457, 238),
(431, 458, 239),
(432, 458, 240),
(439, 460, 242),
(440, 461, 243),
(440, 462, 244),
(442, 469, 246),
(443, 470, 247),
(444, 470, 248),
(451, 472, 250),
(452, 473, 251),
(452, 474, 252),
(454, 481, 254),
(455, 482, 255),
(456, 482, 256),
(463, 484, 258),
(464, 485, 259),
(464, 486, 260),
(466, 493, 262),
(467, 494, 263),
(468, 494, 264),
(475, 496, 266),
(476, 497, 267),
(476, 498, 268),
(478, 505, 270),
(479, 506, 271),
(480, 506, 272),
(487, 508, 274),
(488, 509, 275),
(488, 510, 276),
(490, 517, 278),
(491, 518, 279),
(492, 518, 280),
(499, 520, 282),
(500, 521, 283),
(500, 522, 284),
(502, 529, 286),
(503, 530, 287),
(504, 530, 288),
(511, 532, 290),
(512, 533, 291),
(512, 534, 292),
(514, 541, 294),
(515, 542, 295),
(516, 542, 296),
(523, 544, 298),
(524, 545, 299),
(524, 546, 300),
(526, 553, 302),
(527, 554, 303),
(528, 554, 304);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=556 DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `categories_tasks`
--
ALTER TABLE `categories_tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=530;
--
-- AUTO_INCREMENT for table `categories_tasks`
--
ALTER TABLE `categories_tasks`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=306;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=556;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
